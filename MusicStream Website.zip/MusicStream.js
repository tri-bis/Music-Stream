// music access
document.addEventListener("DOMContentLoaded", function () {
    let userInteracted = false; // Ensures the user interacts first

    // Get all album cards
    const cards = document.querySelectorAll(".trending-album-card");

    // Function to stop all other audios
    function pauseAllAudios() {
        document.querySelectorAll(".audio-player").forEach(audio => {
            audio.pause();
            audio.currentTime = 0;
        });

        document.querySelectorAll(".play-pause-btn i").forEach(icon => {
            icon.classList.replace("fa-pause", "fa-play");
        });
    }

    // Loop through each album card
    cards.forEach(card => {
        let audio = card.querySelector(".audio-player");
        let button = card.querySelector(".play-pause-btn");
        let icon = button.querySelector("i");

        if (!audio || !button || !icon) return;

        // Play when hovering (only after interaction)
        card.addEventListener("mouseenter", () => {
            if (!userInteracted) return; // Block auto-play until interaction

            pauseAllAudios();
            audio.play();
            icon.classList.replace("fa-play", "fa-pause");
        });

        // Stop when leaving
        card.addEventListener("mouseleave", () => {
            audio.pause();
            icon.classList.replace("fa-pause", "fa-play");
        });

        // Click to toggle play/pause (also enables hover play)
        button.addEventListener("click", (event) => {
            event.stopPropagation();
            userInteracted = true; // Unlock autoplay

            if (audio.paused) {
                pauseAllAudios();
                audio.play();
                icon.classList.replace("fa-play", "fa-pause");
            } else {
                audio.pause();
                icon.classList.replace("fa-pause", "fa-play");
            }
        });
    });

    // First click anywhere unlocks autoplay
    document.body.addEventListener("click", () => {
        userInteracted = true;
    });
});


// countdown
const concertDate = new Date("2025-06-15T20:00:00").getTime();

    function updateCountdown() {
        let now = new Date().getTime();
        let timeLeft = concertDate - now;

        if (timeLeft < 0) {
            document.getElementById("countdown").innerHTML = "Concert has started!";
            return;
        }

        let days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
        let hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        let minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
        let seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

        document.getElementById("countdown").innerHTML = 
            `${days}d ${hours}h ${minutes}m ${seconds}s`;
    }

    setInterval(updateCountdown, 1000);
    updateCountdown();

    