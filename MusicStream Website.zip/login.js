document.addEventListener("DOMContentLoaded", function () {
    const emailInput = document.querySelector(".email");
    const passwordInput = document.querySelector(".password");
    const loginButton = document.querySelector(".submit");

    // Load saved email from local storage
    const savedEmail = localStorage.getItem("savedEmail");
    if (savedEmail) {
        emailInput.value = savedEmail;
    }

    // Form Validation and Login Simulation
    loginButton.addEventListener("click", function (event) {
        event.preventDefault(); // Prevent form submission

        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();

        if (email === "" || password === "") {
            alert("Please enter both email/username and password.");
            return;
        }

        if (!email.includes("@") && email.length < 3) {
            alert("Please enter a valid email or username.");
            return;
        }

        if (password.length < 6) {
            alert("Password must be at least 6 characters long.");
            return;
        }

        // Hardcoded credentials (for testing)
        const correctEmail = "user@example.com";
        const correctPassword = "password123";

        if (email === correctEmail && password === correctPassword) {
            alert("Login successful!");

            // Save email to local storage
            localStorage.setItem("savedEmail", email);

            // Redirect to dashboard (Change as needed)
            window.location.href = "dashboard.html"; 
        } else {
            alert("Incorrect email/username or password.");
        }
    });
});
